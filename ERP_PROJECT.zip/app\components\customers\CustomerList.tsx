"use client";

import CustomerRow from "./CustomerRow";
import { useCustomers } from "@/app/hooks/useCustomers";

export default function CustomerList() {
  const { customers, loading } = useCustomers();

  if (loading) {
    return (
      <p className="mt-10 text-center">
        Loading Customers...
      </p>
    );
  }

  if (customers.length === 0) {
    return (
      <p className="mt-10 text-center text-white">
        No Customers Found
      </p>
    );
  }

  return (
    <table className="w-full border-collapse border border-slate-700">
      <thead className="bg-orange-600 text-white">
        <tr>
          <th className="p-3 text-left">Customer</th>
          <th className="p-3 text-left">Mobile</th>
          <th className="p-3 text-left">Credit Limit</th>
          <th className="p-3 text-left">Action</th>

        </tr>
      </thead>

      <tbody>
        {customers.map((customer) => (
          <CustomerRow
            key={customer.id}
            customer={customer}
          />
        ))}
      </tbody>
    </table>
  );
}