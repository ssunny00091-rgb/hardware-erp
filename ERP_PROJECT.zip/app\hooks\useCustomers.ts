"use client";

import { useEffect, useState } from "react";
import { Customer } from "@/app/types/customer";
import { CustomerService } from "@/app/services/customer.service";

export function useCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  async function loadCustomers() {
    try {
      const data = await CustomerService.getAll();
      setCustomers(data);
    } catch (error) {
      console.error("Failed to load customers:", error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCustomers();
  }, []);

  return {
    customers,
    loading,
    refresh: loadCustomers,
  };
}