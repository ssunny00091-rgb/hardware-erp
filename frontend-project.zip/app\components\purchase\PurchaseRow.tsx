"use client";

import { useRef } from "react";
import ProductSearch from "../billing/ProductSearch";

type PurchaseRowProps = {
  index: number;
  product: {
    name: string;
    qty: string;
    unit: string;
    price: string;
  };
  productInputRef?: React.Ref<HTMLInputElement>;
  total: number;
  onChange: (
    index: number,
    field: "name" | "qty" | "unit" | "price",
    value: string
  ) => void;
  onDelete: (index: number) => void;
  onAddRow: () => void;
};

export default function PurchaseRow({
  index,
  product,
  productInputRef,
  total,
  onChange,
  onDelete,
  onAddRow,
}: PurchaseRowProps) {
  const qtyRef = useRef<HTMLInputElement>(null);
  const priceRef = useRef<HTMLInputElement>(null);

  return (
    <div className="mb-3 grid grid-cols-5 gap-3">
      <ProductSearch
        ref={productInputRef}
        value={product.name}
        onChange={(value) => onChange(index, "name", value)}
        onSelect={(name, price, unit) => {
          onChange(index, "name", name);
          onChange(index, "price", price.toString());
          onChange(index, "unit", unit);

          setTimeout(() => {
            qtyRef.current?.focus();
          }, 0);
        }}
      />

      <input
        ref={qtyRef}
        type="number"
        placeholder="Qty"
        value={product.qty}
        onChange={(e) => onChange(index, "qty", e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            priceRef.current?.focus();
          }
        }}
        className="rounded-xl border border-white/20 bg-white/10 p-3 text-white"
      />

      <input
        ref={priceRef}
        type="number"
        placeholder="Purchase Price"
        value={product.price}
        onChange={(e) => onChange(index, "price", e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            onAddRow();
          }
        }}
        className="rounded-xl border border-white/20 bg-white/10 p-3 text-white"
      />

      <div className="flex items-center justify-center rounded-xl border border-white/20 bg-white/10 font-bold text-green-400">
        ₹{total}
      </div>

      <button
        onClick={() => onDelete(index)}
        className="rounded-xl bg-red-500 p-3 text-white hover:bg-red-600"
      >
        🗑
      </button>
    </div>
  );
}