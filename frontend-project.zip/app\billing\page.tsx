"use client";

import { useEffect, useRef, useState } from "react";

import { supabase } from "../lib/supabase";

import BillingForm from "../../components/billing/BillingForm";
import BillingRow from "../../components/billing/BillingRow";
import BillingSummary from "../../components/billing/BillingSummary";

type BillingProduct = {
  name: string;
  qty: string;
  unit: string;
  price: string;
};

type Product = {
  id: number;
  product_name: string;
  stock: number;
};

export default function BillingPage() {
  const [customerName, setCustomerName] = useState("");
  const [mobile, setMobile] = useState("");
  const [invoiceNo, setInvoiceNo] = useState("");
  const [billDate, setBillDate] = useState(
    new Date().toISOString().split("T")[0]
  );

  const [products, setProducts] = useState<BillingProduct[]>([
    {
      name: "",
      qty: "",
      unit: "Piece",
      price: "",
    },
  ]);

  const [productMaster, setProductMaster] = useState<Product[]>([]);
  const productRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    fetchProducts();

    setInvoiceNo(`INV-${Date.now()}`);
  }, []);

  const fetchProducts = async () => {
    const { data } = await supabase
      .from("products")
      .select("*")
      .order("product_name");

    setProductMaster(data || []);
  };

  const handleProductChange = (
    index: number,
    field: "name" | "qty" | "unit" | "price",
    value: string
  ) => {
    setProducts((prev) => {
      const updated = [...prev];

      updated[index] = {
        ...updated[index],
        [field]: value,
      };

      return updated;
    });
  };

  const addRow = () => {
    setProducts((prev) => {
      const updated = [
        ...prev,
        {
          name: "",
          qty: "",
          unit: "Piece",
          price: "",
        },
      ];

      setTimeout(() => {
        productRefs.current[updated.length - 1]?.focus();
      }, 0);

      return updated;
    });
  };

  const deleteRow = (index: number) => {
    setProducts(products.filter((_, i) => i !== index));
  };

  const grandTotal = products.reduce((total, item) => {
    return total + Number(item.qty) * Number(item.price);
  }, 0);

  const saveBill = async () => {
    const validProducts = products.filter(
      (p) =>
        p.name.trim() !== "" &&
        Number(p.qty) > 0 &&
        Number(p.price) > 0
    );

    if (validProducts.length === 0) {
      alert("Please add at least one product.");
      return;
    }

    const { error } = await supabase
      .from("sales")
      .insert([
        {
          customer_name: customerName,
          mobile,
          invoice_no: invoiceNo,
          bill_date: billDate,
          products: validProducts,
          total: grandTotal,
        },
      ]);

    if (error) {
      alert(error.message);
      return;
    }

    // Stock Reduce
    for (const item of validProducts) {
      const { data: product } = await supabase
        .from("products")
        .select("id, stock")
        .eq("product_name", item.name)
        .maybeSingle();

      if (!product) continue;

      await supabase
        .from("products")
        .update({
          stock: Number(product.stock) - Number(item.qty),
        })
        .eq("id", product.id);
    }

    alert("✅ Bill Saved Successfully");

    setCustomerName("");
    setMobile("");
    setInvoiceNo(`INV-${Date.now()}`);

    setProducts([
      {
        name: "",
        qty: "",
        unit: "Piece",
        price: "",
      },
    ]);
  };

  return (
    <main className="min-h-screen bg-slate-900 p-8">
      <div className="mx-auto max-w-7xl">

        <h1 className="mb-8 text-4xl font-bold text-white">
          🧾 Billing
        </h1>

        <BillingForm
  customerName={customerName}
  mobile={mobile}
  invoiceNo={invoiceNo}
  billDate={billDate}
  onCustomerChange={setCustomerName}
  onMobileChange={setMobile}
  onInvoiceChange={setInvoiceNo}
  onDateChange={setBillDate}
/>

        

        <div className="mt-8">

          <div className="mb-4 grid grid-cols-5 gap-3 rounded-xl bg-white/10 p-4 text-white">
            <div>Product</div>
            <div>Qty</div>
            <div>Price</div>
            <div>Total</div>
            <div>Action</div>
          </div>

          {products.map((product, index) => (
            <BillingRow
              key={index}
              index={index}
              product={product}
              productInputRef={(el) => {
                productRefs.current[index] = el;
              }}
              total={Number(product.qty) * Number(product.price)}
              onChange={handleProductChange}
              onDelete={deleteRow}
              onAddRow={addRow}
            />
          ))}

        </div>

        <BillingSummary
          grandTotal={grandTotal}
          onAddRow={addRow}
          onSave={saveBill}
        />

        </div>
      
    </main>
  );
}